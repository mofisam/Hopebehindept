<?php
    // Database connection
$conn = new mysqli('localhost', 'root', '1234', 'Hopebehindebt');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>